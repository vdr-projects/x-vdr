import os, sys
scriptdir = os.path.abspath(os.path.dirname(sys.argv[0]))
sys.path.append(scriptdir + "/lib/")
sys.path.append(scriptdir + "/sites/")
os.chdir(scriptdir)


from Googlyrics import *
g = Googlyrics()

title = "Bubbi Morthens"
artist = "Martin Rap"
outlyric = g.find_lyrics(title, artist)[0].getLyric()
print outlyric.lyrics

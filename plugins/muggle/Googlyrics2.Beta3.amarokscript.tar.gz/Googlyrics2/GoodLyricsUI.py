#!/usr/bin/env python

import os, sys, pygtk, gobject, gtk, gtk.glade, time, threading, SocketServer
pygtk.require("2.0")

import SimpleXMLRPCServer
scriptdir = os.path.abspath(os.path.dirname(sys.argv[0]))
sys.path.append(scriptdir + "/lib/")
sys.path.append(scriptdir + "/sites/")
os.chdir(scriptdir)

from Googlyrics import *

class GoodLyricsUI:
    def __init__(self, rpc):
        #Set the Glade file
        self.gladefile = "goodlyrics.glade"
        self.wTree = gtk.glade.XML(self.gladefile) 
        #Get the Main Window, and connect the "destroy" event
        self.window = self.wTree.get_widget("window1")
        self.window.show()
        self.window.connect("destroy", self.kill)
        dic = {"goback" : self.prevLyrics,
               "gonext" : self.nextLyrics,
               "gobutton" : self.readEntryLyrics
                }
                
        self.wTree.signal_autoconnect(dic)
        self.lyricbuffer = gtk.TextBuffer()
        self.wTree.get_widget("lyricsview").set_buffer(self.lyricbuffer)
        rpc.ui = self
        self.rpc = rpc        
    def readEntryLyrics(self, data):
        artist = self.wTree.get_widget("artistentry").get_text()
        title = self.wTree.get_widget("titleentry").get_text()
        self.rpc.showLyrics(artist, title)
    def prevLyrics(self, data):
        self.rpc.prevLyrics()
    def nextLyrics(self, data):
        self.rpc.nextLyrics()
    def kill(self, data):
        exit()    
                
         
class RPCLyrics:
    ui = None
    def __init__(self):
        self.g = Googlyrics()    
        
    def showLyrics(self, artist, title):
        self.setLyrics("Loading...", artist, title)
        starttime = time.time()
        self.outlyric = self.g.find_lyrics(title, artist)
        self.lynum = 0
        if len(self.outlyric) == 0:
            self.setLyrics("No lyrics for track found", artist, title)
        else:
            self.loadly()
            totaltime = time.time() - starttime
            return True
        return False
    def nextLyrics(self):
        self.lynum += 1
        self.loadly()
    def prevLyrics(self):
        self.lynum -= 1
        self.loadly()
    def loadly(self):
        try:
            lyric = self.outlyric[self.lynum].getLyric()
            self.setLyrics(lyric.lyrics+"\nFetched from %s" % lyric.url, lyric.artist, lyric.title)
        except IndexError:
            pass
        except AttributeError:
            self.lynum += 1
            self.loadly()
    def setLyrics(self, lyricstr, artist, title):
        print "setting to:" + lyricstr
        self.ui.lyricbuffer.set_text(lyricstr)
        self.ui.wTree.get_widget("artistentry").set_text(artist)
        self.ui.wTree.get_widget("titleentry").set_text(title)
class RPCServerThread(threading.Thread):
    rpcobj = None
    def run(self):
        server = SimpleXMLRPCServer.SimpleXMLRPCServer(("127.0.0.1", 8888))
        server.register_instance(self.rpcobj)
        print "Listening on port 8888"
        server.serve_forever()
if __name__ == "__main__":
    rpcobj = RPCLyrics()
    srv = RPCServerThread()
    srv.rpcobj = rpcobj
    srv.start()
    gui = GoodLyricsUI(rpcobj)
    gobject.threads_init()
    gtk.main()

#!/usr/bin/env python
import sys, re, os, urllib, urllib2
from xml.dom import getDOMImplementation

scriptdir = os.path.abspath(os.path.dirname(sys.argv[0]))
sys.path.append(scriptdir + "/lib/")
sys.path.append(scriptdir + "/sites/")
os.chdir(scriptdir)

from Googlyrics import Googlyrics
class AmarokCtl:
    def run(self):
        g = Googlyrics()
        while True:
            line = sys.stdin.readline()
            if line.startswith("configure"):
                os.spawnlp(os.P_WAIT,"dcop", "dcop", "amarok", "playlist", "popupMessage", "This script does not require any configuration.");
            elif line.startswith("fetchLyrics"):
                command, artist, title = line.split(" ")
                artist = re.compile(r'\(.*?\)').sub("", artist)
                title = re.compile(r'\(.*?\)').sub("", title)
                try:
                    hits = g.find_lyrics(urllib.unquote(title), urllib.unquote(artist))
                    for ly in hits:
                        lyric = ly.getLyric()
                        if lyric is not None:
                            outlyric = lyric
                            break
                    dom = getDOMImplementation()
                    if outlyric is None:
                        doc = dom.createDocument('', 'suggestions', '')
                        doc.documentElement.setAttribute('title', urllib.unquote(title))
                        doc.documentElement.setAttribute('artist', urllib.unquote(artist))
                    else:
                        doc = dom.createDocument('', 'lyrics', '')
                        doc.documentElement.setAttribute('title', outlyric.title)
                        doc.documentElement.setAttribute('artist', outlyric.artist)
                        doc.documentElement.setAttribute('site', outlyric.sitename)
                        doc.documentElement.setAttribute('site_url', outlyric.siteurl)
                        doc.documentElement.setAttribute('page_url', outlyric.url)
                        doc.documentElement.appendChild(doc.createTextNode(outlyric.lyrics))
                    doctxt = doc.toxml()
                except OSError:
                    doctxt = ""
                os.spawnlp(os.P_WAIT, "dcop", "dcop", "amarok", "contextbrowser", "showLyrics", doctxt);
a = AmarokCtl()
a.run()

import SimpleXMLRPCServer
import os, sys
scriptdir = os.path.abspath(os.path.dirname(sys.argv[0]))
sys.path.append(scriptdir + "/lib/")
sys.path.append(scriptdir + "/sites/")
os.chdir(scriptdir)


from Googlyrics import *
g = Googlyrics()
#The server object
class LyricSearcher:
    def showLyrics(self, title, artist):
        try:
            outlyric = g.find_lyrics(title, artist)
            if outlyric is None:
                print "No lyrics for track found"
            else:
                print outlyric.lyrics
                return True
        except:
            print "Something is WRONG! (Probably a network error) :P"
        return False
srch = LyricSearcher()
server = SimpleXMLRPCServer.SimpleXMLRPCServer(("192.168.1.142", 8888))
server.register_instance(srch)

#Go into the main listener loop
print "Listening on port 8888"
server.serve_forever()

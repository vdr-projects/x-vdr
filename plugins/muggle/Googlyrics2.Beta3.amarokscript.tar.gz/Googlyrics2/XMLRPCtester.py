import xmlrpclib
server = xmlrpclib.ServerProxy("http://localhost:8888")
server.showLyrics("Smash Mouth", "All Star")

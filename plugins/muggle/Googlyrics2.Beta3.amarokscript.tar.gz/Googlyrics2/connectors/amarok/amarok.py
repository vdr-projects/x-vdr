import dbus, xmlrpclib, time, commands

artist = ""
title = ""
def gettrack():
    status, artist = commands.getstatusoutput("dcop amarok player artist")
    status, title = commands.getstatusoutput("dcop amarok player title")
    return {"artist": artist, "name": title}
server = xmlrpclib.ServerProxy("http://localhost:8888")
while True:
	track = gettrack()
	if (track["name"], track["artist"]) != (title, artist):
		title = str(track["name"])
		artist = str(track["artist"])
		if title != "" and artist != "":
		    server.showLyrics(artist, title)
	time.sleep(0.1)


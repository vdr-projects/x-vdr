#!/usr/bin/env python
import dbus, xmlrpclib, time
bus = dbus.SessionBus()
audacious = bus.get_object("org.atheme.audacious", "/Player")
artist = ""
title = ""
while True:
	track = audacious.GetMetadata()
	if (track["title"], track["artist"]) != (title, artist):
		title = str(track["title"])
		artist = str(track["artist"])
		server = xmlrpclib.ServerProxy("http://localhost:8888")
		server.showLyrics(artist, title)
	time.sleep(0.1)


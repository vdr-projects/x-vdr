#!/usr/bin/env python
import xmlrpclib
from PyAs import AudioSurf
class GoodAudiosurf:
    def send(self):
        print "%s - %s" % (self.artist, self.title)
        server = xmlrpclib.ServerProxy("http://192.168.1.142:8888")
        server.showLyrics(self.artist, self.title)
        self.artist = ""
        self.title = ""
    def OnSongTitle(self,title):
        self.title = title
        if self.artist != "":
            self.send()
    def OnArtistName(self,artist):
        self.artist = artist
        if self.title != "":
            self.send()
    def __init__(self):
        self.artist = ""
        self.title = ""
        a = AudioSurf()
        a.callbacks["nowplayingsongtitle"].append(self.OnSongTitle)
        a.callbacks["nowplayingartistname"].append(self.OnArtistName)
        a.run()
go = GoodAudiosurf()
#!/usr/bin/env python
import wx
import sys, win32api, win32gui, win32con, array, struct, urllib
from ctypes import *

class CopyDataStruct(Structure):
  _fields_ = [('dwData', c_int),
              ('cbData', c_int),
              ('lpData', c_void_p)]

class AudioSurf:
    def __init__(self):
        self.callbacks = {
            "oncharacterscreen": [],
            "songcomplete": [],
            "nowplayingsongtitle": [],
            "nowplayingartistname": [],
            "nowplayingashfile": []
        }
        self.ashwnd = win32gui.FindWindow(None, 'Audiosurf')
        self.app = wx.PySimpleApp()
        self.frame = wx.Frame( None, -1, "PyAS", size = ( 200, 50 ) )
        self.SendASCommand("ascommand registerlistenerwindow PyAS")
        self.oldWndProc = win32gui.SetWindowLong(self.frame.GetHandle(),win32con.GWL_WNDPROC ,self.MyWndProc )        
    def run(self):
        #self.frame.Show()
        self.app.MainLoop()
    def SendASCommand(self, cmd):
        s = create_string_buffer(cmd)
        cds = CopyDataStruct(len(s), len(s), cast(s, c_void_p))
        win32api.SendMessage(self.ashwnd, win32con.WM_COPYDATA, 0, addressof(cds))
    def Close(self):
        self.SendASCommand("ascommand closeaudiosurf")
    def MyWndProc(self, hWnd, msg, wParam, lParam ):
        if msg == win32con.WM_COPYDATA: 
            #get the struct-string from the memory address
            structure = string_at( lParam, 12 )
    
            #unpack the data
            data = struct.unpack("IIP", structure)
            unused, str_len, str_adr = data
    
            #and finally get the real string from the memory
            my_string = string_at( str_adr, str_len )
            
            out = my_string.replace('\x00','').split(" ")
            if out[1] == "songcomplete":
                for f in self.callbacks["songcomplete"]: f(int(out[3]))
            elif out[1] == "oncharacterscreen":
                for f in self.callbacks["oncharacterscreen"]: f()
            elif out[1] == "nowplayingsongtitle":
                for f in self.callbacks["nowplayingsongtitle"]: f(urllib.unquote_plus(out[2]))
            elif out[1] == "nowplayingartistname":
                for f in self.callbacks["nowplayingartistname"]: f(urllib.unquote_plus(out[2]))
            elif out[1] == "nowplayingashfile":
                for f in self.callbacks["nowplayingashfile"]: f(out[2])
        return win32gui.CallWindowProc( self.oldWndProc, hWnd, msg, wParam, lParam )
if __name__ == "__main__":
    a = AudioSurf()
    a.run()
#!/usr/bin/env python
import dbus, xmlrpclib, time
bus = dbus.SessionBus()
banshee = bus.get_object("org.bansheeproject.Banshee", "/org/bansheeproject/Banshee/PlayerEngine")
artist = ""
title = ""
while True:
	track = banshee.GetCurrentTrack()
	if (track["name"], track["artist"]) != (title, artist):
		title = str(track["name"])
		artist = str(track["artist"])
		server = xmlrpclib.ServerProxy("http://localhost:8888")
		server.showLyrics(artist, title)
	time.sleep(0.1)


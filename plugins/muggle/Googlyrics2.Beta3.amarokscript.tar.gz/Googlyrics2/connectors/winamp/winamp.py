# Originally based off winamp.py by Shalabh Chaturvedi
# Tested against foobar2000's winamp_spam plugin

import win32api
import win32gui
import time, re, xmlrpclib

WM_COMMAND = 0x0111
WM_USER    = 0x400

def voidfunc():
    pass

class winamp:
    def __init__(self):
        self.hWinamp = win32gui.FindWindow('Winamp v1.x', None)

    def __getattr__(self, attr):
        self.command(attr)
        return voidfunc

    def usercommand(self, id, data=0):
        return win32api.SendMessage(self.hWinamp, WM_USER, data, id)
        
    def getPlayingStatus(self):
        "returns the current status string which is one of 'playing', 'paused' or 'stopped'"
        iStatus = self.usercommand(104)
        if iStatus == 1:
            return 'playing'
        elif iStatus == 3:
            return 'paused'
        else:
            return 'stopped'
            
    def getCurrentTrackName(self):
		instr = win32gui.GetWindowText(self.hWinamp)
		regex = re.compile('\d*?\. (.*?) - (.*?) - Winamp')
		m = regex.match(instr)
		if m is None:
			return "", ""
		artist = m.group(1)
		title = m.group(2)
		return artist, title


w = winamp()
server = xmlrpclib.ServerProxy("http://192.168.1.142:8888")
(artist, title) = ("","")
while 1:
	if w.getPlayingStatus() == "playing":
		newartist, newtitle = w.getCurrentTrackName()
		if (artist, title) != (newartist, newtitle):
			artist, title = w.getCurrentTrackName()
			print artist + " - " + title
			server.showLyrics(artist, title)
	time.sleep(0.1)


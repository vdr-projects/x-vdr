#!/usr/bin/env python
from google import *
from LyricSearchResult import *
from ConfigParser import ConfigParser
import sys
import urllib
import os
import re
import uniquify

class Googlyrics:
    plugins = []
    def __init__(self):
        config = ConfigParser()
        config.read("config.ini")
        plugs = config.get("Googlyrics", "plugins").split(" ")
        loaded = 0
        for plug in plugs:
            exec "from " + plug +" import *"
            exec "self.plugins.append(" + plug + "())"
            loaded += 1
    
    def find_lyrics(self, title, artist):
        qs = [
            'intitle:"' + artist + ' - ' + title + '" lyrics',
            '"' + title + '" "' + artist + '" lyrics',
            title + ' ' + artist + ' lyrics',
            ]
        resultlist = []
        for q in qs:
            query = GoogleQuery(q)
            for url in query.get_all_urls():
                for plug in self.plugins:
                    if plug.url_match(url):
                        resultlist.append(LyricSearchResult(plug, url, title, artist))
        return uniquify.unique(resultlist)
        
        
    def test_all(self):
        for plug in self.plugins:
            print "Test of " + plug.name
            if plug.url_match(plug.testurl):
                if plug.selftest():
                    print " passed"
                else:
                    print " failed"
            else:
                print plug.name + " rejected test url"
if __name__ == '__main__':
    sys.path.append("./lib/")
    sys.path.append("./sites/")
    g = Googlyrics()
    g.test_all()

class Lyric:
    lyrics = ""
    siteurl = ""
    sitename = ""
    url = ""
    artist = ""
    title = ""
    
    def __init__(self, title, artist, url, sitename, siteurl, lyrics):
        self.lyrics = unicode(lyrics, 'iso-8859-1')
        self.title = unicode(title, 'iso-8859-1')
        self.url = url
        self.sitename = sitename
        self.siteurl = siteurl
        self.artist = unicode(artist, 'iso-8859-1')
    

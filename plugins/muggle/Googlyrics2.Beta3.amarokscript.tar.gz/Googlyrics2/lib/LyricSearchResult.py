class LyricSearchResult:
    plugin = None
    title = ""
    artist = ""
    url = ""
    
    def __cmp__(self, other):
        if self.url == other.url:
            return 0
        else:
            return 1

    def __init__(self, plugin, url, title, artist):
        self.plugin = plugin
        self.url = url
        self.title = title
        self.artist = artist
        
    def getLyric(self):
        return self.plugin.get_lyrics(self.url, self.title, self.artist)
        
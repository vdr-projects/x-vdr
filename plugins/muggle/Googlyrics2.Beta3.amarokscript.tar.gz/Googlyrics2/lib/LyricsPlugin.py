#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib
import re

class LyricsPlugin:
    name = ""
    site = ""
    testurl = ""
    
    def url_match(self, url):
        pass
    
    def get_lyrics(self, url, title, artist):
        pass

    def no_strip(self, data):
        data = re.compile(r'<.*?>').sub("", data)
        return data.strip()

    def default_strip(self,data):
        data = re.compile(r'\r\n').sub("", data)
        data = re.compile(r'\n').sub("", data)
        data = re.compile(r'<br>').sub("\n", data)
        data = re.compile(r'<br />').sub("\n", data)
        data = re.compile(r'<br/>').sub("\n", data)
        data = re.compile(r'<BR>').sub("\n", data)
        data = urllib.unquote(re.compile(r'%92').sub("&apos", urllib.quote(data)))
        data = re.compile(r'<.*?>').sub("", data)
        data = re.compile(r'Please enable javascript to see this content.').sub("", data)
        return data.strip()

#!/usr/bin/env python
from LyricsPlugin import *
import re
import urllib2
import cookielib
from Lyric import Lyric

class RegexLyrics(LyricsPlugin):
    siteregex = re.compile(r'')
    regex = re.compile(r'')
    stripfunction = LyricsPlugin.default_strip
    
    def url_match(self, url):
        if self.siteregex.search(url):
            return True
        else:
            return False
    
    def selftest(self):
        return self.get_lyrics(self.testurl, "", "")
    
    def get_lyrics(self, url, title, artist):
        try:
            cj = cookielib.LWPCookieJar()
            opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
            urllib2.install_opener(opener)
            page = urllib2.urlopen(url).read()
            result = self.regex.search(page)
            if result:
                return Lyric(title, artist, url, self.name, self.site, self.stripfunction(result.group(1)))
            else:
                return None
        except:
            return None

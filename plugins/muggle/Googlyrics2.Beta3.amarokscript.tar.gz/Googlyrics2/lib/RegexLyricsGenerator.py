#!/usr/bin/env python
basicmodule = """#!/usr/bin/env python
from RegexLyrics import *

class #MODNAME#(RegexLyrics):
    siteregex = re.compile(r'#SITEREGEX#')
    site = "#SITEURL#"
    name = "#SITENAME#"
    regex = re.compile(r'#REGEX#', re.DOTALL)
    testurl = "#TESTURL#"

if __name__ == "__main__":
    a = #MODNAME#()
    print a.selftest().lyrics
"""
modname = raw_input("Enter class name:").strip()
basicmodule = basicmodule.replace("#MODNAME#", modname)
basicmodule = basicmodule.replace("#SITEREGEX#", raw_input("Enter regex for site (for google query):").strip())
basicmodule = basicmodule.replace("#SITEURL#", raw_input("Enter site URL:").strip())
basicmodule = basicmodule.replace("#SITENAME#", raw_input("Enter site name:").strip())
basicmodule = basicmodule.replace("#REGEX#", raw_input("Enter lyric regex:").strip())
basicmodule = basicmodule.replace("#TESTURL#", raw_input("Enter test URL:").strip())
print basicmodule
fh = open("%s.py" % modname, "w")
fh.write(basicmodule)
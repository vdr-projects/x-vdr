#!/usr/bin/env python
import urllib2 
import urllib
import re

class GoogleQuery:
    def __init__(self, query):
        request = urllib2.Request("http://www.google.ca/search?num=100&start=" + "&q=" + urllib.quote_plus(query))
        request.add_header('User-Agent', 'IE6 :D') 
        opener = urllib2.build_opener() 
        self.page = opener.open(request).read()
    
    def get_all_urls(self):
        urlre = re.compile(r'<h3 class=r[>].*?<a href=\"(.*?)\"')
        return urlre.findall(self.page)

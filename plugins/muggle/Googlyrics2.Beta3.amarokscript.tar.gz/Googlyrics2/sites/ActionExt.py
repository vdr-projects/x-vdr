#!/usr/bin/env python
from RegexLyrics import *

class ActionExt(RegexLyrics):
    siteregex = re.compile(r'actionext\.com')
    site = "actionext.com"
    name = "Actionext"
    regex = re.compile(r'name="lyrics">(.*)</textarea>', re.DOTALL)
    testurl = "http://www.actionext.com/names_b/bubbi_morthens_lyrics/martin_rap.html"

if __name__ == "__main__":
    a = ActionExt()
    print a.selftest().lyrics

#!/usr/bin/env python
from RegexLyrics import *

class AzLyrics(RegexLyrics):
    siteregex = re.compile(r'azlyrics\.com')
    site = "azlyrics.com"
    name = "AzLyrics"
    testurl = "http://www.azlyrics.com/lyrics/adamsandler/fouryearsold.html"
    regex = re.compile(r'<FONT size=2>.*?<BR>\s*(.*?)\[ <a href="http:\/\/www.azlyrics.com">www.azlyrics.com<\/a> \]<BR><BR>', re.DOTALL)

#!/usr/bin/env python
from RegexLyrics import *

class FreeLyrics(RegexLyrics):
    siteregex = re.compile(r'free-lyrics\.net')
    site = "free-lyrics.net"
    name = "Free Lyrics"
    regex = re.compile(r'<td class="style5" style="font-weight:normal;padding-left:5px;">(.*?)</td>', re.DOTALL)
    testurl = "http://www.free-lyrics.net/Rihanna-lyrics/437.html"

if __name__ == "__main__":
    a = FreeLyrics()
    print a.selftest().lyrics
#!/usr/bin/env python
from RegexLyrics import *

class HotLyrics(RegexLyrics):
    siteregex = re.compile(r'hotlyrics\.net')
    site = "hotlyrics.net"
    name = "Hot Lyrics"
    regex = re.compile(r'<!-- GOOGLE END //-->(.*?)<script type="text/javascript">', re.DOTALL)
    testurl = "http://www.hotlyrics.net/lyrics/L/Lil_Wayne/Lollipop.html"

if __name__ == "__main__":
    a = HotLyrics()
    print a.selftest().lyrics

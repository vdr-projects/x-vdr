#!/usr/bin/env python
from RegexLyrics import *

class JustSomeLyrics(RegexLyrics):
    siteregex = re.compile(r'justsomelyrics\.com')
    site = "justsomelyrics.com"
    name = "Just Some Lyrics"
    regex = re.compile(r'phone2.gif" alt="phone" />(.*?)<div class="adsdiv">', re.DOTALL)
    testurl = "http://www.justsomelyrics.com/1223644/Banned-from-T.V.-You-Can't-Always-Get-What-You-Want-Lyrics"

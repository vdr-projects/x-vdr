#!/usr/bin/env python
from RegexLyrics import *

class Kovach(RegexLyrics):
    siteregex = re.compile(r'kovach.co.yu')
    site = "kovach.co.yu"
    name = "Kovach"
    regex = re.compile(r'>Z</a>.*?<td width="100%" valign="top">(.*?)</td></tr></table>', re.DOTALL)
    testurl = "http://www.kovach.co.yu/16x8x23_-_Apaci_lyric.html"

if __name__ == "__main__":
    a = Kovach()
    print a.selftest().lyrics

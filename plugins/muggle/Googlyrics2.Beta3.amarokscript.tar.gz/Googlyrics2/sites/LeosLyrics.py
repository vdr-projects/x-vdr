#!/usr/bin/env python
from RegexLyrics import *

class LeosLyrics(RegexLyrics):
    siteregex = re.compile(r'leoslyrics\.com')
    site = "leoslyrics.com"
    name = "Leo's Lyrics"
    regex = re.compile(r'<font face="Trebuchet MS, Verdana, Arial" size=-1>(.*?)<\/font>', re.DOTALL)
    testurl = "http://leoslyrics.com/listlyrics.php;jsessionid=6821C9C2BDE8AC2071DB14E18E06561A?hid=rxak6OW4U%2BU%3D"

if __name__ == "__main__":
    a = LeosLyrics()
    print a.selftest().lyrics

#!/usr/bin/env python
from RegexLyrics import *

class Letras(RegexLyrics):
    siteregex = re.compile(r'letras.terra.com.br')
    site = "letras.terra.com.br"
    name = "Letras"
    regex = re.compile(r'<p id=\'cmp\'>.*?</p>(.*?)</p><br/>', re.DOTALL)
    testurl = "http://letras.terra.com.br/victor-leo/995776/"

if __name__ == "__main__":
    a = Letras()
    print a.selftest().lyrics

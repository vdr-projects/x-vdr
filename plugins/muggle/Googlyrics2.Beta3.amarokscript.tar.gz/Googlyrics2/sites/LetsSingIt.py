#!/usr/bin/env python
from RegexLyrics import *

class LetsSingIt(RegexLyrics):
    siteregex = re.compile(r'letssingit\.com')
    site = "letssingit.com"
    name = "Let's Sing It"
    regex = re.compile(r'phone_right.gif" ALIGN="absmiddle" border=0 vspace=o hspace=0></A>(.*)<DIV align="center">', re.DOTALL)
    testurl = "http://artists.letssingit.com/jason-mraz-lyrics-im-yours-lmcfr63"
    stripfunction = LyricsPlugin.no_strip

if __name__ == "__main__":
    a = LetsSingIt()
    print a.selftest().lyrics

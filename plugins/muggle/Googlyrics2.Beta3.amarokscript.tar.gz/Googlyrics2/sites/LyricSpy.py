#!/usr/bin/env python
from RegexLyrics import *

class LyricSpy(RegexLyrics):
    siteregex = re.compile(r'lyricspy\.com')
    site = "lyricspy.com"
    name = "LyircSpy"
    regex = re.compile(r'mobile2.gif" border="0" />(.*?)<div', re.DOTALL)
    testurl = "http://www.lyricspy.com/a/A_Canorous_Quintet/lyrics/Burning_Emotionless/"

if __name__ == "__main__":
    a = LyricSpy()
    print a.selftest().lyrics

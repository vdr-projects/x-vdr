#!/usr/bin/env python
from RegexLyrics import *

class LyricWiki(RegexLyrics):
    siteregex = re.compile(r'lyricwiki.org')
    site = "lyricwiki.org"
    name = "LyricWiki"
    regex = re.compile(r'<div class=\'lyricbox\' >(.*?)</div', re.DOTALL)
    testurl = "http://lyricwiki.org/Timbaland:The_Way_I_Are"

if __name__ == "__main__":
    a = LyricWiki()
    print a.selftest().lyrics

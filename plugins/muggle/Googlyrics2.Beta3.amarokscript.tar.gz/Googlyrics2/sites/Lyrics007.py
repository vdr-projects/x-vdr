#!/usr/bin/env python
from RegexLyrics import *

class Lyrics007(RegexLyrics):
    siteregex = re.compile(r'lyrics007\.com')
    site = "lyrics007.com"
    name = "Lyrics007"
    regex = re.compile(r'phone2.gif"><br><br><br></div>(.*?)<div align=center>', re.DOTALL)
    testurl = "http://www.lyrics007.com/Barenaked%20Ladies%20Lyrics/For%20You%20Lyrics.html"
    

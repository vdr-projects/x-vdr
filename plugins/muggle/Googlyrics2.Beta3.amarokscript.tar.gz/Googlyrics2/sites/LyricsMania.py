#!/usr/bin/env python
from RegexLyrics import *

class LyricsMania(RegexLyrics):
    siteregex = re.compile(r'lyricsmania.com')
    site = "lyricsmania.com"
    name = "LyricsMania"
    regex = re.compile(r'</strong> :</br>(.*?)<span style="font-size:14px;">', re.DOTALL)
    testurl = "http://www.lyricsmania.com/lyrics/armin_van_buuren_lyrics_8253/imagine_lyrics_83504/going_wrong_lyrics_824533.html"

if __name__ == "__main__":
    a = LyricsMania()
    print a.selftest().lyrics

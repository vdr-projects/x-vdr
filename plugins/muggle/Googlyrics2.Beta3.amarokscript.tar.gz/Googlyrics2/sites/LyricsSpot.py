#!/usr/bin/env python
from RegexLyrics import *

class LyricsSpot(RegexLyrics):
    siteregex = re.compile(r'lyricsspot.com')
    site = "lyricsspot.com"
    name = "Lyrics Spot"
    regex = re.compile(r'"Ringtones" border="no"><p><br><font size="2">(.*?)<img src="/images/phone-left.gif"', re.DOTALL)
    testurl = "http://lyricsspot.com/millionaires-alcohol-lyrics-1610851.html"

if __name__ == "__main__":
    a = LyricsSpot()
    print a.selftest().lyrics

#!/usr/bin/env python
from RegexLyrics import *

class LyricsTime(RegexLyrics):
    siteregex = re.compile(r'lyricstime.com')
    site = "lyricstime.com"
    name = "LyricsTime"
    regex = re.compile(r'phone-right.gif" width="18" height="18" alt="Ringtones" border="no">(.*?)</p></p>', re.DOTALL)
    testurl = "http://lyricstime.com/a-bad-goodbye-dreamland-lyrics.html"

if __name__ == "__main__":
    a = LyricsTime()
    print a.selftest().lyrics

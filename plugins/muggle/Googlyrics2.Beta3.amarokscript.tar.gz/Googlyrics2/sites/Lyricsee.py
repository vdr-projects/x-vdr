#!/usr/bin/env python
from RegexLyrics import *

class Lyricsee(RegexLyrics):
    siteregex = re.compile(r'lyrics\.ee')
    site = "lyrics.ee"
    name = "Lyrics.ee"
    regex = re.compile(r'<img src="img/lyrics/icon_add.gif" alt="Lisa laul" border="0"></a></td></tr>.*?-->(.*?)<p><br>', re.DOTALL)
    testurl = "http://lyrics.ee/est/lyrics/artists/show_song/id-128573"

if __name__ == "__main__":
    a = Lyricsee()
    print a.selftest().lyrics

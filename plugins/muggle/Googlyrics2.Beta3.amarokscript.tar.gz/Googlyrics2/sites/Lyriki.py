#!/usr/bin/env python
from RegexLyrics import *

class Lyriki(RegexLyrics):
    siteregex = re.compile(r'lyriki.com')
    site = "lyriki.com"
    name = "Lyriki"
    regex = re.compile(r'<\/div>\n<p>(.*?)<\/p>', re.DOTALL)
    testurl = "http://www.lyriki.com/10_Years:Wasteland"

if __name__ == "__main__":
    a = Lyriki()
    print a.selftest().lyrics

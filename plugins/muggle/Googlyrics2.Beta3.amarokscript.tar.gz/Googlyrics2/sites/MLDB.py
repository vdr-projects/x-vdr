#!/usr/bin/env python
from RegexLyrics import *

class MLDB(RegexLyrics):
    siteregex = re.compile(r'mldb\.org')
    site = "mldb.org"
    name = "MLDB"
    regex = re.compile(r'<p class=songtext>(.*?)<\/table>', re.DOTALL)
    testurl = "http://www.mldb.org/song-144514-act-one-prologue.html"

if __name__ == "__main__":
    a = MLDB()
    print a.selftest().lyrics

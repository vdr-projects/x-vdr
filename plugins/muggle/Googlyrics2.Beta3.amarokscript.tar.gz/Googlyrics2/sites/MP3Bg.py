#!/usr/bin/env python
from RegexLyrics import *

class MP3Bg(RegexLyrics):
    siteregex = re.compile(r'mp3-bg.com')
    site = "mp3-bg.com"
    name = "mp3-bg"
    regex = re.compile(r'<\/h2><p>(.*?)<ul class="admin">', re.DOTALL)
    testurl = "http://www.mp3-bg.com/lyrics/Raina-Studeni-44,64,816.html"

if __name__ == "__main__":
    a = MP3Bg()
    print a.selftest().lyrics

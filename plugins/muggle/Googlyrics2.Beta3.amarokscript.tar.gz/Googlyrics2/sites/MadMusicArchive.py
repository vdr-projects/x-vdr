#!/usr/bin/env python
from RegexLyrics import *

class MadMusicArchive(RegexLyrics):
    siteregex = re.compile(r'themadmusicarchive\.com')
    site = "themadmusicarchive.com"
    name = "The Mad Music Archive"
    regex = re.compile(r'<td><span class="Verdana8">(.*?)<\/span>', re.DOTALL)
    testurl = "http://www.themadmusicarchive.com/song_details.aspx?SongID=24430"

if __name__ == "__main__":
    a = MadMusicArchive()
    print a.selftest().lyrics

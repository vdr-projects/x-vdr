#!/usr/bin/env python
from RegexLyrics import *

class MegaLyrics(RegexLyrics):
    siteregex = re.compile(r'megalyrics.ru')
    site = "megalyrics.ru"
    name = "MegaLyrics"
    regex = re.compile(r'http://pagead2.googlesyndication.com/pagead/show_ads.js">(.*?)<br><a href=\"javascript', re.DOTALL)
    testurl = "http://megalyrics.ru/lyric48291.htm"

if __name__ == "__main__":
    a = MegaLyrics()
    print a.selftest().lyrics

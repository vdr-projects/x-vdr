#!/usr/bin/env python
from RegexLyrics import *

class MetroLyrics(RegexLyrics):
    siteregex = re.compile(r'metrolyrics\.com')
    site = "metrolyrics.com"
    name = "MetroLyrics"
    regex = re.compile(r'blue_small_trans_right.gif">(.*?)<img', re.DOTALL)
    testurl = "http://www.metrolyrics.com/7-things-lyrics-miley-cyrus.html"

if __name__ == "__main__":
    a = MetroLyrics()
    print a.selftest().lyrics
#!/usr/bin/env python
from RegexLyrics import *

class MyLyricsBox(RegexLyrics):
    siteregex = re.compile(r'mylyricsbox.com')
    site = "mylyricsbox.com"
    name = "My Lyircs Box"
    regex = re.compile(r'<div class="songLyrics">(.*?)<\/div>', re.DOTALL)
    testurl = "http://www.mylyricsbox.com/Nightwish/Angels-Fall-First/A-Return-To-The-Sea-lyrics.105708"

if __name__ == "__main__":
    a = MyLyricsBox()
    print a.selftest().lyrics

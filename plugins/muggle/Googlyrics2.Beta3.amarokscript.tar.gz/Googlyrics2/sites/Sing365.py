#!/usr/bin/env python
from RegexLyrics import *

class Sing365(RegexLyrics):
    siteregex = re.compile(r'sing365\.com')
    site = "sing365.com"
    name = "Sing365"
    regex = re.compile(r'phone2.gif border=0>(.*?)<DIV ALIGN=center>', re.DOTALL)
    testurl = "http://www.sing365.com/music/lyric.nsf/Call-And-Answer-lyrics-Barenaked-Ladies/DDD74144C093A13848256895000F37FA"
    

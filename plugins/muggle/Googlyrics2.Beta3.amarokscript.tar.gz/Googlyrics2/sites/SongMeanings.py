#!/usr/bin/env python
from RegexLyrics import *

class SongMeanings(RegexLyrics):
    siteregex = re.compile(r'songmeanings.net')
    site = "songmeanings.net"
    name = "Song Meanings"
    regex = re.compile(r'<td width="100%" style="text-align:left;">.*<td width="100%" style="text-align:left;">\s*(.*?)\s*<\/td>', re.DOTALL)
    testurl = "http://www.songmeanings.net/lyric.php?lid=3530822107858634683&artist=7710"

if __name__ == "__main__":
    a = SongMeanings()
    print a.selftest().lyrics

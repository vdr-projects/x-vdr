#!/usr/bin/env python
from RegexLyrics import *

class WeAreTheLyrics(RegexLyrics):
    siteregex = re.compile(r'wearethelyrics.com')
    site = "wearethelyrics.com"
    name = "We Are The Lyrics"
    regex = re.compile(r'<\/h3>\n<p>\s*(.*?)\s*<\/p>', re.DOTALL)
    testurl = "http://www.wearethelyrics.com/2/ken_stringfellow_lyrics_14027/cyclone_graves_lyrics_162925.html"

if __name__ == "__main__":
    a = WeAreTheLyrics()
    print a.selftest().lyrics
